=== HTML2WP ===
Contributors: Ars
Tags: import, pages, html, post
Requires at least: 4.7
Tested up to: 5.9.1
Stable tag: 1.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
 
Simple plugin for importing html files to wordpress as pages or posts
